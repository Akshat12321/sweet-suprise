# Romantic Birthday Gift App

## What I’ll build
- A mobile-first six-screen birthday experience inside a phone-like canvas on larger screens.
- A PIN lock using `1311`, including wrong-code shake feedback and a successful next state.
- A confetti birthday greeting, an interactive three-gift hub, and opened-gift checkmarks.
- An animated candle cake with blow-out interaction, a photo scrapbook, and an opening love-letter envelope.
- All three supplied photos used throughout the polaroids, with two thoughtfully reused because only three images were attached.

## Visual direction
- Romantic pastel blush, coral, cream, and soft white.
- Playful display typography paired with a handwritten accent.
- Polaroids, paper textures, tape, stickers, soft shadows, and subtle motion.

## Technical details
- Keep editable photos and messages in a single config object at the top of the main page file.
- Use Motion for screen transitions and interactions, canvas-confetti for celebrations, and Lucide icons for controls.
- Upload supplied photos through the project asset flow and reference their generated asset pointers.
- Add route-specific metadata and verify the complete flow at desktop and mobile sizes.
