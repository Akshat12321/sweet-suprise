import { createFileRoute } from "@tanstack/react-router";
import confetti from "canvas-confetti";
import { AnimatePresence, motion } from "motion/react";
import { ArrowLeft, Check, Gift, Heart, LockKeyhole, Mail, PartyPopper, Sparkles } from "lucide-react";
import { useEffect, useState } from "react";

import { Button } from "@/components/ui/button";
import togetherAsset from "@/assets/us-together.png.asset.json";
import mirrorAsset from "@/assets/mirror-photo.png.asset.json";
import callAsset from "@/assets/video-call.png.asset.json";

const BIRTHDAY_CONFIG = {
  pin: "1311",
  photos: [togetherAsset.url, mirrorAsset.url, callAsset.url, togetherAsset.url, mirrorAsset.url],
  notes: ["Every day feels warmer with you.", "You are my favourite hello.", "More laughs, more memories, more us."],
  letter: `Happy birthday, my love.

You make ordinary days feel magical and every memory worth keeping. I hope this year brings you the same joy, comfort, and love you bring into my life.

Here’s to your smile, your dreams, and every beautiful moment still waiting for us. I’m so lucky to have you.

Forever yours ❤️`,
} as const;

type Screen = "PIN_LOCK" | "CELEBRATION" | "GIFT_HUB" | "GIFT_CAKE" | "GIFT_SCRAPBOOK" | "GIFT_LETTER";
type GiftScreen = Extract<Screen, `GIFT_${string}`>;

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "A Little Birthday Surprise" },
      { name: "description", content: "Unlock a private birthday surprise made with love." },
      { property: "og:title", content: "A Little Birthday Surprise" },
      { property: "og:description", content: "Unlock a private birthday surprise made with love." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: BirthdayApp,
});

const screenMotion = {
  initial: { opacity: 0, rotateY: -8, x: 22 },
  animate: { opacity: 1, rotateY: 0, x: 0 },
  exit: { opacity: 0, rotateY: 8, x: -22 },
};

function BirthdayApp() {
  const [screen, setScreen] = useState<Screen>("PIN_LOCK");
  const [opened, setOpened] = useState<GiftScreen[]>([]);

  const openGift = (gift: GiftScreen) => {
    setOpened((current) => (current.includes(gift) ? current : [...current, gift]));
    setScreen(gift);
  };

  return (
    <main className="min-h-[100svh] bg-secondary/60 sm:grid sm:place-items-center sm:p-5">
      <section className="relative min-h-[100svh] w-full overflow-hidden bg-background sm:min-h-0 sm:h-[min(900px,calc(100svh-40px))] sm:max-w-[560px] sm:rounded-[2rem] sm:border sm:border-primary/15 sm:shadow-romantic">
        <div className="pointer-events-none absolute inset-0 opacity-30 [background-image:radial-gradient(var(--color-primary)_0.7px,transparent_0.7px)] [background-size:18px_18px]" />
        <AnimatePresence mode="wait">
          <motion.div key={screen} {...screenMotion} transition={{ duration: 0.38, ease: "easeOut" }} className="relative h-full min-h-[100svh] sm:min-h-0">
            {screen === "PIN_LOCK" && <PinLock onNext={() => setScreen("CELEBRATION")} />}
            {screen === "CELEBRATION" && <Celebration onNext={() => setScreen("GIFT_HUB")} />}
            {screen === "GIFT_HUB" && <GiftHub opened={opened} onOpen={openGift} />}
            {screen === "GIFT_CAKE" && <CakeGift onBack={() => setScreen("GIFT_HUB")} />}
            {screen === "GIFT_SCRAPBOOK" && <Scrapbook onBack={() => setScreen("GIFT_HUB")} />}
            {screen === "GIFT_LETTER" && <LoveLetter onBack={() => setScreen("GIFT_HUB")} />}
          </motion.div>
        </AnimatePresence>
      </section>
    </main>
  );
}

function PinLock({ onNext }: { onNext: () => void }) {
  const [pin, setPin] = useState("");
  const [wrong, setWrong] = useState(false);
  const unlocked = pin === BIRTHDAY_CONFIG.pin;

  const press = (key: string) => {
    if (unlocked || key === "*" || key === "#") return;
    const next = `${pin}${key}`.slice(0, 4);
    setPin(next);
    if (next.length === 4 && next !== BIRTHDAY_CONFIG.pin) {
      setWrong(true);
      window.setTimeout(() => { setPin(""); setWrong(false); }, 560);
    }
  };

  return (
    <div className="flex h-full min-h-[100svh] flex-col px-6 py-8 sm:min-h-0 sm:px-10 sm:py-9">
      <div className="mb-5 flex items-center gap-2 text-xs font-bold uppercase tracking-[0.18em] text-primary"><LockKeyhole size={15} /> For your eyes only</div>
      <div className="grid flex-1 items-center gap-7 sm:grid-cols-[0.9fr_1.1fr]">
        <Polaroid src={BIRTHDAY_CONFIG.photos[0]} alt="A favourite memory together" className="mx-auto w-[58%] -rotate-3 sm:w-full" caption="you + me, always ♡" />
        <div className="text-center">
          <p className="font-hand text-lg font-bold text-primary">psst... a surprise!</p>
          <h1 className="mt-1 text-2xl font-extrabold text-foreground">Enter a passcode</h1>
          <motion.div animate={wrong ? { x: [-8, 8, -7, 7, 0] } : { x: 0 }} className="my-5 flex justify-center gap-2.5">
            {[0, 1, 2, 3].map((i) => <span key={i} className={`grid size-11 place-items-center rounded-lg border-2 text-xl font-bold transition-colors ${unlocked ? "border-success bg-success/10 text-success" : wrong ? "border-destructive bg-destructive/10" : "border-primary/25 bg-card"}`}>{pin[i] ? "♥" : ""}</span>)}
          </motion.div>
          <div className="mx-auto grid max-w-[250px] grid-cols-3 gap-x-5 gap-y-2">
            {["1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "0", "#"].map((key) => (
              <motion.button whileTap={{ scale: 0.82 }} type="button" key={key} onClick={() => press(key)} className="aspect-square rounded-full border border-primary/10 bg-card text-lg font-bold text-foreground shadow-soft transition-colors hover:bg-secondary" aria-label={`Key ${key}`}>{key}</motion.button>
            ))}
          </div>
          <p className="mt-4 font-hand text-base text-muted-foreground">hint: it&apos;s our fav code ❤️</p>
          <AnimatePresence>{unlocked && <motion.div initial={{ opacity: 0, scale: 0.7 }} animate={{ opacity: 1, scale: 1 }} transition={{ type: "spring", bounce: 0.45 }} className="mt-4"><Button variant="birthday" size="gift" onClick={onNext}>Next <Sparkles /></Button></motion.div>}</AnimatePresence>
        </div>
      </div>
    </div>
  );
}

function Celebration({ onNext }: { onNext: () => void }) {
  useEffect(() => {
    const colors = ["#FF4B6E", "#FFB4C2", "#FFD166", "#FFF9F5"];
    confetti({ particleCount: 120, spread: 80, origin: { y: 0.45 }, colors });
  }, []);
  return <div className="flex h-full min-h-[100svh] flex-col items-center justify-center bg-cream px-8 text-center sm:min-h-0">
    <div className="absolute left-7 top-9 rotate-[-14deg] text-5xl">🎈</div><div className="absolute right-8 top-14 rotate-12 text-4xl">🎉</div>
    <motion.div animate={{ y: [0, -10, 0], rotate: [-2, 2, -2] }} transition={{ repeat: Infinity, duration: 2.3 }} className="relative mb-8 text-[8rem] leading-none">🧸<span className="absolute -bottom-2 -right-4 text-6xl">🎂</span></motion.div>
    <p className="font-hand text-2xl font-bold text-primary">today is all about you</p>
    <h1 className="mt-2 max-w-sm text-5xl font-extrabold leading-[0.95] text-primary sm:text-6xl">HAPPY<br />BIRTHDAY!</h1>
    <p className="mt-5 max-w-xs text-sm leading-6 text-muted-foreground">I wrapped a few little moments just for you.</p>
    <Button variant="birthday" size="gift" onClick={onNext} className="absolute bottom-8 right-7">Next <PartyPopper /></Button>
  </div>;
}

const gifts: Array<{ screen: GiftScreen; label: string; icon: string; color: string }> = [
  { screen: "GIFT_CAKE", label: "Make a wish", icon: "🎂", color: "bg-coral" },
  { screen: "GIFT_SCRAPBOOK", label: "Our memories", icon: "🎁", color: "bg-accent" },
  { screen: "GIFT_LETTER", label: "Open me", icon: "💌", color: "bg-primary" },
];

function GiftHub({ opened, onOpen }: { opened: GiftScreen[]; onOpen: (gift: GiftScreen) => void }) {
  return <div className="flex h-full min-h-[100svh] flex-col px-7 py-10 sm:min-h-0 sm:px-10">
    <div className="text-center"><Gift className="mx-auto mb-2 text-primary" size={28} /><h1 className="font-script text-4xl text-primary">Gift for you</h1><p className="mt-2 text-sm text-muted-foreground">click any gift to open</p></div>
    <div className="my-auto grid gap-4">
      {gifts.map((gift, i) => <motion.button type="button" key={gift.screen} onClick={() => onOpen(gift.screen)} whileTap={{ scale: 0.94 }} className="relative flex w-full items-center gap-5 rounded-lg border border-primary/10 bg-card p-4 text-left shadow-soft">
        <motion.span animate={{ y: [0, -7, 0] }} transition={{ repeat: Infinity, duration: 2.4 + i * 0.35, delay: i * 0.25 }} className={`grid size-20 shrink-0 place-items-center rounded-lg text-5xl ${gift.color}`}>{gift.icon}</motion.span><span><span className="block text-[10px] font-bold uppercase tracking-[0.18em] text-primary">Gift 0{i + 1}</span><span className="mt-1 block text-lg font-extrabold text-foreground">{gift.label}</span></span>
        {opened.includes(gift.screen) && <span className="absolute right-4 top-4 grid size-6 place-items-center rounded-full bg-success text-primary-foreground" aria-label="Opened"><Check size={14} /></span>}
      </motion.button>)}
    </div>
    <p className="text-center font-hand text-lg text-primary">made with a whole lot of love ♡</p>
  </div>;
}

function CakeGift({ onBack }: { onBack: () => void }) {
  const [blown, setBlown] = useState(false);
  const blow = () => { setBlown(true); confetti({ particleCount: 90, spread: 65, origin: { y: 0.55 }, colors: ["#FFE4E8", "#FF2E55", "#FFD166"] }); };
  return <div className="flex h-full min-h-[100svh] flex-col items-center justify-center bg-coral px-6 text-center text-primary-foreground sm:min-h-0">
    <p className="font-hand text-2xl font-bold">{blown ? "your wish is on its way..." : "close your eyes & make a wish"}</p>
    <motion.h1 layout className="mt-2 font-script text-4xl">{blown ? "happy birthday my love ✨" : "A little wish for you"}</motion.h1>
    <div className="relative my-16 h-64 w-72">
      <div className="absolute bottom-0 left-1/2 h-8 w-64 -translate-x-1/2 rounded-[50%] bg-cocoa/25" />
      <div className="absolute bottom-5 left-1/2 h-28 w-60 -translate-x-1/2 rounded-lg bg-paper shadow-romantic"><div className="h-7 rounded-t-lg bg-primary/25" /><div className="font-hand pt-5 text-2xl font-bold text-primary">1311 wishes ♡</div></div>
      <div className="absolute bottom-[8.1rem] left-1/2 h-16 w-40 -translate-x-1/2 rounded-t-lg bg-secondary"><div className="mt-3 flex justify-around text-primary">♥ ♥ ♥</div></div>
      {["-ml-[42px]", "ml-0", "ml-[42px]"].map((offset) => <div key={offset} className={`absolute bottom-[12.1rem] left-1/2 h-14 w-2.5 rounded-t bg-primary-foreground ${offset}`}><AnimatePresence>{!blown ? <motion.span exit={{ opacity: 0, scale: 0 }} className="flame-flicker absolute -top-7 left-1/2 h-8 w-5 origin-bottom rounded-[50%_50%_45%_45%] bg-accent" /> : <span className="smoke-rise absolute -top-5 left-1/2 text-xl text-primary-foreground/70">〰</span>}</AnimatePresence></div>)}
    </div>
    {!blown ? <Button variant="cream" size="gift" onClick={blow}>Blow</Button> : <Button variant="cream" size="gift" onClick={onBack}><ArrowLeft /> Back</Button>}
  </div>;
}

function Scrapbook({ onBack }: { onBack: () => void }) {
  return <div className="relative h-full min-h-[100svh] overflow-y-auto bg-paper px-6 pb-24 pt-8 sm:min-h-0">
    <div className="text-center"><span className="text-3xl">🍒</span><h1 className="font-script text-3xl text-primary">Happy birthday baby</h1><p className="font-hand text-lg text-muted-foreground">a tiny book of us</p></div>
    <div className="relative mx-auto mt-7 min-h-[650px] max-w-md">
      <Polaroid src={BIRTHDAY_CONFIG.photos[1]} alt="A mirror selfie" caption="my favourite view" className="absolute left-0 top-2 w-[56%] -rotate-6" imageClassName="rotate-90 scale-[1.42]" />
      <div className="absolute right-0 top-12 w-[38%] rotate-3 rounded-md border border-primary/15 bg-cream p-3 font-hand text-xl font-bold text-primary shadow-soft">“{BIRTHDAY_CONFIG.notes[0]}”</div>
      <span className="absolute right-5 top-48 rotate-12 text-4xl">💗</span>
      <Polaroid src={BIRTHDAY_CONFIG.photos[2]} alt="A sweet video call memory" caption="even far feels close" className="absolute right-0 top-60 w-[58%] rotate-5" />
      <div className="absolute left-0 top-[22rem] w-[39%] -rotate-3 font-hand text-xl font-bold text-cocoa">{BIRTHDAY_CONFIG.notes[1]} <span className="text-primary">♥</span></div>
      <Polaroid src={BIRTHDAY_CONFIG.photos[0]} alt="Together in a mirror" caption="us, always" className="absolute bottom-0 left-2 w-[53%] rotate-3" />
      <div className="absolute bottom-8 right-0 w-[38%] rotate-2 rounded-md bg-secondary p-3 font-hand text-lg font-bold text-primary shadow-soft">{BIRTHDAY_CONFIG.notes[2]}</div>
    </div>
    <Button variant="birthday" size="gift" onClick={onBack} className="fixed bottom-6 right-[max(1.5rem,calc(50vw-250px))] z-20"><ArrowLeft /> Back</Button>
  </div>;
}

function LoveLetter({ onBack }: { onBack: () => void }) {
  const [open, setOpen] = useState(false);
  return <div className="relative flex h-full min-h-[100svh] flex-col items-center overflow-y-auto bg-secondary px-6 pb-24 pt-10 sm:min-h-0">
    <Mail className="text-primary" /><h1 className="mt-2 font-script text-3xl text-primary">A letter for you</h1>
    <div className="relative mt-8 w-full max-w-md pb-52 [perspective:1000px]">
      <motion.button type="button" aria-label="Open love letter" onClick={() => setOpen(true)} className="relative z-10 mx-auto block h-48 w-[88%] rounded-md bg-primary shadow-romantic" animate={open ? { y: 180 } : { y: 70 }}>
        <div className="absolute inset-0 [clip-path:polygon(0_0,50%_58%,100%_0,100%_100%,0_100%)] bg-primary-strong" />
        <motion.div animate={{ rotateX: open ? 180 : 0 }} transition={{ duration: 0.65 }} className="absolute inset-x-0 top-0 h-28 origin-top bg-coral [clip-path:polygon(0_0,100%_0,50%_100%)]" />
        {!open && <span className="absolute left-1/2 top-20 grid size-12 -translate-x-1/2 place-items-center rounded-full bg-accent text-xl">♥</span>}
      </motion.button>
      <motion.article initial={false} animate={open ? { y: -110, opacity: 1 } : { y: 75, opacity: 0 }} transition={{ type: "spring", stiffness: 85, damping: 16, delay: open ? 0.28 : 0 }} className="relative z-20 mx-auto w-[92%] rounded-sm bg-cream px-6 py-7 text-left shadow-soft">
        <Heart className="mb-3 fill-primary text-primary" size={20} /><p className="whitespace-pre-line font-hand text-lg leading-6 text-cocoa">{BIRTHDAY_CONFIG.letter}</p><p className="mt-3 font-script text-xl text-primary">Always, me</p>
      </motion.article>
      <Polaroid src={BIRTHDAY_CONFIG.photos[3]} alt="A favourite shared moment" className="absolute -left-2 top-[24rem] z-30 w-28 -rotate-6" />
      <Polaroid src={BIRTHDAY_CONFIG.photos[4]} alt="A mirror selfie memory" className="absolute -right-2 top-[26rem] z-30 w-28 rotate-6" imageClassName="rotate-90 scale-[1.4]" />
    </div>
    {!open && <p className="absolute bottom-20 font-hand text-lg text-primary">tap the envelope to open ♡</p>}
    <Button variant="birthday" size="gift" onClick={onBack} className="fixed bottom-6 right-[max(1.5rem,calc(50vw-250px))] z-40"><ArrowLeft /> Back</Button>
  </div>;
}

function Polaroid({ src, alt, caption, className = "", imageClassName = "" }: { src: string; alt: string; caption?: string; className?: string; imageClassName?: string }) {
  return <figure className={`relative bg-card p-2 pb-8 shadow-soft ${className}`}><span className="absolute -top-3 left-1/2 z-10 h-6 w-16 -translate-x-1/2 rotate-2 bg-accent/70" /><div className="aspect-[4/5] overflow-hidden bg-muted"><img src={src} alt={alt} className={`h-full w-full object-cover ${imageClassName}`} /></div>{caption && <figcaption className="absolute inset-x-2 bottom-1 text-center font-hand text-base font-bold text-cocoa">{caption}</figcaption>}</figure>;
}